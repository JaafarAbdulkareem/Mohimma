import 'package:task_time/models/dropdown_item_model.dart';

List<DropdownItemModel> dropdownData = [
  DropdownItemModel(amout: 30, labelText: 'الإيام', nameValue: 'يوم'),
  DropdownItemModel(amout: 24, labelText: 'الساعات', nameValue: 'ساعة'),
  DropdownItemModel(
    amout: 60,
    defaultValue: 5,
    labelText: 'دقائق',
    nameValue: 'دقيقة',
  ),
];
