import 'package:task_time/models/task_model.dart';

class TaskCubit extends Cubit<List<TaskModel>> {
  TaskCubit() : super([]);

  final Map<String, Timer> _timers = {};
  final AudioPlayer _audioPlayer = AudioPlayer();

  void addTask(String title, int days, int hours, int minutes) {
    final totalSecs = (days * 24 * 3600) + (hours * 3600) + (minutes * 60);
    if (totalSecs <= 0) return;

    final newTask = TaskModel(
      id: DateTime.now().toIso8601String(),
      title: title,
      totalSeconds: totalSecs,
      remainingSeconds: totalSecs,
      isRunning: false,
    );
    emit([...state, newTask]);
  }

  void toggleTimer(String id, {required Function(String) onFinished}) {
    final index = state.indexWhere((element) => element.id == id);
    if (index == -1) return;

    final task = state[index];

    if (task.isRunning) {
      _timers[id]?.cancel();
      _updateTaskState(index, task.copyWith(isRunning: false));
    } else {
      if (task.remainingSeconds <= 0) return;

      final updatedList = List<TaskModel>.from(state);
      updatedList[index] = task.copyWith(isRunning: true);
      emit(updatedList);

      _timers[id] = Timer.periodic(const Duration(seconds: 1), (timer) {
        final currentIndex = state.indexWhere((element) => element.id == id);
        if (currentIndex == -1) {
          timer.cancel();
          return;
        }

        final currentTask = state[currentIndex];
        if (currentTask.remainingSeconds > 1) {
          _updateTaskState(
            currentIndex,
            currentTask.copyWith(
              remainingSeconds: currentTask.remainingSeconds - 1,
            ),
          );
        } else {
          timer.cancel();
          _updateTaskState(
            currentIndex,
            currentTask.copyWith(remainingSeconds: 0, isRunning: false),
          );
          _playSound();
          onFinished(currentTask.title);
        }
      });
    }
  }

  Future<void> _playSound() async {
    try {
      // استخدام صوت افتراضي أو ملف من الأصول
      await _audioPlayer.play(AssetSource('alarm.mp3'));
    } catch (e) {
      // في حال عدم توفر الملف، يمكن تجاهله أو استخدام صوت النظام إن وجد
    }
  }

  void _updateTaskState(int index, TaskModel updatedTask) {
    final updatedList = List<TaskModel>.from(state);
    updatedList[index] = updatedTask;
    emit(updatedList);
  }

  @override
  Future<void> close() {
    for (var timer in _timers.values) {
      timer.cancel();
    }
    _audioPlayer.dispose();
    return super.close();
  }
}
