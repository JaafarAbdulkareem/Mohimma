class ChangeDropdownCubit extends Cubit<int> {
  ChangeDropdownCubit() : super(0);

  void changeValue(int value) {
    emit(value);
  }
}
