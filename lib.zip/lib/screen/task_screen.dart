import 'package:flutter/material.dart';
import 'package:task_time/manage/task_cubit.dart';
import 'package:task_time/models/task_model.dart';
import 'package:task_time/widgets/custom_floating_action_button.dart';
import 'package:task_time/widgets/item_task.dart';

class TasksScreen extends StatelessWidget {
  const TasksScreen({super.key});

  String _formatTime(int totalSeconds) {
    int days = totalSeconds ~/ 86400;
    int hours = totalSeconds ~/ 3600;
    int minutes = (totalSeconds % 3600) ~/ 60;
    int seconds = totalSeconds % 60;
    return '${days.toString().padLeft(2, '0')}:${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إدارة المهام والعد التنازلي'),
        centerTitle: true,
      ),
      body: BlocBuilder<TaskCubit, List<TaskModel>>(
        builder: (context, tasks) {
          if (tasks.isEmpty) {
            return const Center(
              child: Text(
                'لا توجد مهام حالياً، اضغط على زر + لإضافة مهمة جديدة',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            );
          }
          return ListView.builder(
            itemCount: tasks.length,
            itemBuilder: (context, index) {
              final task = tasks[index];
              final isFinished = task.remainingSeconds == 0;

              return ItemTask(task: task,isFinished:isFinished);
              
            },
          );
        },
      ),
      floatingActionButton: const CustomFloatingActionButton(),
    );
  }
}
