import 'package:flutter/material.dart';

extension ScaffoldExtinsion on Scaffold {
  // Widget get scaffoldArea => Scaffold(body: SafeArea(child: this));
  Scaffold  scaffoldArea(Widget child) => Scaffold(body: SafeArea(child: child));
}
