class TaskModel extends Equatable {
  final String id;
  final String title;
  final int totalSeconds;
  final int remainingSeconds;
  final bool isRunning;

  const TaskModel({
    required this.id,
    required this.title,
    required this.totalSeconds,
    required this.remainingSeconds,
    required this.isRunning,
  });

  TaskModel copyWith({
    String? title,
    int? totalSeconds,
    int? remainingSeconds,
    bool? isRunning,
  }) {
    return TaskModel(
      id: id,
      title: title ?? this.title,
      totalSeconds: totalSeconds ?? this.totalSeconds,
      remainingSeconds: remainingSeconds ?? this.remainingSeconds,
      isRunning: isRunning ?? this.isRunning,
    );
  }

  @override
  List<Object?> get props => [
    id,
    title,
    totalSeconds,
    remainingSeconds,
    isRunning,
  ];
}
