class DropdownItemModel extends Equatable {
  final int amout;
  final int defaultValue;
  final String labelText;
  final String nameValue;

  DropdownItemModel({
    required this.amout,
    this.defaultValue = 0,
    required this.labelText,
    required this.nameValue,
  });

  DropdownItemModel copyWith({
    int? amout,
    int? defaultValue,
    String? labelText,
    String? nameValue,
  }) {
    return DropdownItemModel(
      amout: amout ?? this.amout,
      defaultValue: defaultValue ?? this.defaultValue,
      labelText: labelText ?? this.labelText,
      nameValue: nameValue ?? this.nameValue,
    );
  }

  @override
  List<Object?> get props => [amout, defaultValue, labelText, nameValue];
}
