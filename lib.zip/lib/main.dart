import 'dart:async';

import 'package:flutter/material.dart';
import 'package:task_time/screen/task_screen.dart';
import 'package:task_time/widgets/custom_floating_action_button.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: BlocProvider(
        create: (context) => TaskCubit(),
        child: const TasksScreen(),
      ),
    );
  }
}
