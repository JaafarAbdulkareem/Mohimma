import 'package:flutter/material.dart';
import 'package:task_time/manage/task_cubit.dart';
import 'package:task_time/models/task_model.dart';

class ItemTask extends StatelessWidget {
  const ItemTask({super.key, required this.task, required this.isFinished});
  final TaskModel task;
  final bool isFinished;
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 3,
      child: ListTile(
        title: Text(
          task.title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            decoration: isFinished ? TextDecoration.lineThrough : null,
            color: isFinished ? Colors.grey : Colors.black87,
          ),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6.0),
          child: Text(
            'الوقت المتبقي: ${_formatTime(task.remainingSeconds)}',
            style: TextStyle(
              color: isFinished ? Colors.red : Colors.blueGrey,
              fontWeight: FontWeight.w600,
              fontSize: 15,
            ),
          ),
        ),
        trailing: IconButton(
          iconSize: 32,
          icon: Icon(
            task.isRunning
                ? Icons.pause_circle_filled
                : Icons.play_circle_filled,
            color: task.isRunning ? Colors.orange : Colors.green,
          ),
          onPressed: isFinished
              ? null
              : () {
                  BlocProvider.of<TaskCubit>(context).toggleTimer(
                    task.id,
                    onFinished: (taskTitle) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('انتهى وقت المهمة: $taskTitle! ⏰'),
                          backgroundColor: Colors.red,
                        ),
                      );
                    },
                  );
                },
        ),
      ),
    );
  }
}
