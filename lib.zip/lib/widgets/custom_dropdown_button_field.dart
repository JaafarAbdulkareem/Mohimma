import 'package:flutter/material.dart';
import 'package:task_time/manage/change_dropdown_cubit.dart';
import 'package:task_time/models/dropdown_item_model.dart';

class CustomDropdownButtonField extends StatelessWidget {
  const CustomDropdownButtonField({
    super.key,
    required this.data,
  });
  final DropdownItemModel data;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child:
       BlocBuilder<ChangeDropdownCubit, int>(){
                builder:(context,state)=>
       DropdownButtonFormField<int>(
        value: state,
        decoration: InputDecoration(
          labelText: data.labelText,
          border: OutlineInputBorder(),
        ),
        items: List.generate(data.amout, (index) => index)
            .map(
              (val) => 
              DropdownMenuItem(
                value: val,
                child: Text('$val ${data.nameValue}'),
              ),
              
             
            )
            .toList(),
        onChanged: (value) {
          selected = value ?? 0;
           BlocProvider.of<ChangeDropdownCubit>(context).changeValue(value);
        },
      ),
       }
    );
  }
}
