import 'package:flutter/material.dart';
import 'package:task_time/data/dropdown_item_data.dart';
import 'package:task_time/widgets/custom_dropdown_button_field.dart';

class CustomFloatingActionButton extends StatelessWidget {
  const new({super.key});
  void _showAddTaskBottomSheet(BuildContext context) {
    final titleController = TextEditingController();
    int selectedDay = 0;
    int selectedHours = 0;
    int selectedMinutes = 5;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'إضافة مهمة جديدة',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              TextField(
                controller: titleController,
                decoration: const InputDecoration(
                  labelText: 'عنوان المهمة',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: ListView.separated(
                  itemBuilder: (BuildContext context, int index) =>
                      CustomDropdownButtonField(data: dropdownData[index]),
                  separatorBuilder: (BuildContext context, int index) =>
                      const SizedBox(height: 16),
                  itemCount: dropdownData.length,
                ).toList(),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                onPressed: () {
                  if (titleController.text.trim().isNotEmpty) {
                    BlocProvider.of<TaskCubit>(context).addTask(
                      titleController.text.trim(),
                      selectedDay,
                      selectedHours,
                      selectedMinutes,
                    );
                    Navigator.pop(ctx);
                  }
                },
                child: const Text(
                  'حفظ وبدء المهمة',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: () => _showAddTaskBottomSheet(context),
      child: const Icon(Icons.add),
    );
  }
}
